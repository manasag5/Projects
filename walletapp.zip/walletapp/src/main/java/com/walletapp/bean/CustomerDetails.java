package com.walletapp.bean;

public class CustomerDetails {
private String customerName;
private String age;
private Long accountNumber;
private double balance;
private String address;
private String moblieNumber;
//private String IFScode;
private String accountType;
private String gender;
private String atmPin;
public String getAge() {
	return age;
}
public void setAge(String age) {
	this.age = age;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public Long getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(Long accountNumber) {
	this.accountNumber = accountNumber;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getMoblieNumber() {
	return moblieNumber;
}
public void setMoblieNumber(String moblieNumber) {
	this.moblieNumber = moblieNumber;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}
public String getAtmPin() {
	return atmPin;
}
public void setAtmPin(String atmPin) {
	this.atmPin = atmPin;
}
public CustomerDetails(Long accountnumber,String customerName,String gender,String age,double balance, String address, String moblieNumber,
		String accountType,String atmPin) {
	super();
	this.accountNumber=accountnumber;
	this.customerName = customerName;
	this.gender=gender;
	this.age=age;
	this.balance = balance;
	this.address = address;
	this.moblieNumber = moblieNumber;
	this.accountType = accountType;
	this.atmPin=atmPin;
	}
public CustomerDetails() {
	super();
}


@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	CustomerDetails other = (CustomerDetails) obj;
	if (accountNumber == null) {
		if (other.accountNumber != null)
			return false;
	} else if (!accountNumber.equals(other.accountNumber))
		return false;
	if (accountType == null) {
		if (other.accountType != null)
			return false;
	} else if (!accountType.equals(other.accountType))
		return false;
	if (address == null) {
		if (other.address != null)
			return false;
	} else if (!address.equals(other.address))
		return false;
	if (age == null) {
		if (other.age != null)
			return false;
	} else if (!age.equals(other.age))
		return false;
	if (atmPin == null) {
		if (other.atmPin != null)
			return false;
	} else if (!atmPin.equals(other.atmPin))
		return false;
	if (Double.doubleToLongBits(balance) != Double.doubleToLongBits(other.balance))
		return false;
	if (customerName == null) {
		if (other.customerName != null)
			return false;
	} else if (!customerName.equals(other.customerName))
		return false;
	if (gender == null) {
		if (other.gender != null)
			return false;
	} else if (!gender.equals(other.gender))
		return false;
	if (moblieNumber == null) {
		if (other.moblieNumber != null)
			return false;
	} else if (!moblieNumber.equals(other.moblieNumber))
		return false;
	return true;
}
@Override
public String toString() {
	return "Customer acc no.=" + accountNumber + ", name=" + customerName + ",Current Balance "+balance ;
}

}
