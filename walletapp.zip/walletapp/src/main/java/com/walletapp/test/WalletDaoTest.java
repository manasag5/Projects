package com.walletapp.test;



import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.walletapp.bean.CustomerDetails;
import com.walletapp.dao.IWalletDao;
import com.walletapp.dao.WalletDao;
import com.walletapp.exception.WalletException;

public class WalletDaoTest {

	 IWalletDao dao=null;
     @Before
     public void setup() {
            dao=new WalletDao();
     }
     
     @After
     public void tearDown() {
            dao = null;
     }
     

     @Test
     public void testCreateAccount() {
            CustomerDetails c = new CustomerDetails();
            c.setAccountNumber(21L);
            c.setCustomerName("Prani");
            c.setMoblieNumber("1234567890");
            c.setAddress("Pune");
            c.setBalance(200000);
            c.setAtmPin("1122");
            
            
            try {
                   dao.addCustomer(c);
                   CustomerDetails c1=dao.getBalance(21L,"1125");
                   assertNotNull(c1);
            } catch (WalletException e) {
                   // TODO Auto-generated catch block
                   System.out.println(e.getMessage());
            }
     }

     @Test
     public void testShowBalance() {
            try {
          	  CustomerDetails c = dao.getBalance(22L,"2345");
                   assertNotNull(c);
                   CustomerDetails c1 = dao.getBalance(25L,"2345");
                   assertNull(c1);
            } catch (WalletException e) {
                   // TODO Auto-generated catch block
                   System.out.println(e.getMessage());
            }
     }
     
     @Test
     public void testDepositPositive() throws WalletException {
  	   CustomerDetails c = new CustomerDetails();
  	   c.setAccountNumber(22L);
  	   c.setCustomerName("Ben");
  	   c.setBalance(2343445.33);
            assertNotSame(c, dao.setDeposit(12345678911L,"2345","1000"));
     }
     
     @Test
     public void testWithdrawPositive() throws WalletException {
  	   CustomerDetails c = new CustomerDetails();
  	   c.setAccountNumber(22L);
  	   c.setCustomerName("Ben");
  	   c.setBalance(1886700.00);
  	 assertNotSame(c, dao.getWithdraw(22L,"2345","2000"));
     }
     
     @Test
     public void testFundTransferPositive() throws WalletException {
  	   CustomerDetails c = new CustomerDetails();
  	   c.setAccountNumber(22L);
  	   c.setCustomerName("Ben");
  	   c.setBalance(2343445.33);
  	 assertNotSame(c, dao.getFundTransfer(21L,22L,"1125","100"));
     }
     @Test
     public void testPrintTransaction() throws WalletException {
  	assertFalse(dao.getPrintTransactions(22L,"2345"));
	 
     }
     
}   



