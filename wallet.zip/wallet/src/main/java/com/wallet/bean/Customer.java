package com.wallet.bean;

public class Customer {

	private String name;
	private String address;
	private String age;
	private String phone;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public Customer(String name, String address, String age, String phone) {
		super();
		this.name = name;
		this.address = address;
		this.age = age;
		this.phone = phone;
	}
	public Customer() {
		super();
	}
	
	
	
	
}
